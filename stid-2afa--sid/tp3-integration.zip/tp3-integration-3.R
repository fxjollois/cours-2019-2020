library(tidyverse)
library(lubridate)

# Extract des tables via le script
source("tp3-integration-2.R")

# Calcul de la dimension date
Commande %>%
  mutate(minDate = min(ymd(DateCom), ymd(ALivAvant), ymd(DateEnv), na.rm = T),
         maxDate = max(ymd(DateCom), ymd(ALivAvant), ymd(DateEnv), na.rm = T)) %>%
  select(minDate, maxDate) %>%
  slice(1) -> minmax
duree = minmax$maxDate - minmax$minDate + 1
DimDate = data.frame(cleDate = c(-1, 1 + (0:duree)),
                     Date = c("date inconnue", as.character(minmax$minDate + 0:duree)),
                     stringsAsFactors = FALSE) %>%
  mutate(
    Jour = ifelse(cleDate > 0, day(ymd(Date)), NA),
    Mois = ifelse(cleDate > 0, month(ymd(Date)), NA),
    Annee = ifelse(cleDate > 0, year(ymd(Date)), NA)
  )
rm(duree, minmax)

# Calcul de la dimension Client
DimClient = Client %>%
  transmute(cleClient = CodeCli, 
            NomClient = Societe,
            VilleClient = Ville,
            PaysClient = Pays)

# Calcul de la dimension Produit
DimProduit = Produit %>%
  inner_join(Fournisseur) %>%
  inner_join(Categorie) %>%
  transmute(cleProduit      = Refprod,
            NomProduit      = Nomprod,
            Fournisseur     = Societe,
            PaysFournisseur = Pays,
            Categorie       = NomCateg)

# Calcul de la dimension Employe
DimEmploye = Employe %>%
  transmute(cleEmploye = NoEmp,
            NomEmp     = Nom,
            PrenomEmp  = Prenom,
            VilleEmp   = Ville,
            PaysEmp    = Pays)

# Calcul de la table de faits Vente
FaitVente = DetailCommande %>%
  inner_join(Commande, by = c("Nocom" = "NoCom")) %>%
  inner_join(DimDate, by = c("DateCom" = "Date")) %>%
  inner_join(Messager %>% mutate(NoMess = as.character(NoMess))) %>%
  transmute(cleFaitVente  = row_number(),
            cleDate       = cleDate,
            cleClient     = CodeCli,
            cleProduit    = Refprod,
            cleEmploye    = NoEmp,
            Messager      = NomMess,
            MontantTotal  = PrixUnit * Qte * (1 - Remise),
            PrixUnit      = PrixUnit,
            Quantite      = Qte,
            MontantRemise = PrixUnit * Qte * Remise)

# Calcul de la table FaitCommande
FaitCommande = Commande %>%
  left_join(DetailCommande %>% 
               group_by(Nocom) %>% summarise(Mt = sum(PrixUnit * Qte * (1 - Remise))),
             by = c("NoCom" = "Nocom")) %>%
  left_join(Messager %>% mutate(NoMess = as.character(NoMess))) %>%
  left_join(DimDate, by = c("DateCom" = "Date"), suffix = c("", "Cde")) %>%
  left_join(DimDate, by = c("DateEnv" = "Date"), suffix = c("", "Env")) %>%
  left_join(DimDate, by = c("ALivAvant" = "Date"), suffix = c("", "Lim")) %>%
  transmute(cleFaitCde = NoCom,
            cleClient  = CodeCli,
            cleEmploye = NoEmp,
            cleDateCde = cleDate,
            cleDateEnvoi = cleDateEnv,
            cleDateLim = cleDateLim,
            Messager  = NomMess,
            MontantTotal = Mt,
            Port = Port) %>%
  mutate(cleDateEnvoi = ifelse(is.na(cleDateEnvoi), -1, cleDateEnvoi))

rm(Categorie, Client, Commande, DetailCommande,
   Employe, Fournisseur, Messager, Produit)
