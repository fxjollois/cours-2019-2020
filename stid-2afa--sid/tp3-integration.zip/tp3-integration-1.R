library(DBI)

dm = dbConnect(RSQLite::SQLite(), "datamart.sqlite")

# Création des tables
dbExecute(dm, "
CREATE TABLE DimDate (
  cleDate INT PRIMARY KEY,
  Date DATE,
  Jour INT,
  Mois INT,
  Annee INT
);")
dbExecute(dm, "
CREATE VIEW DimDateCde AS
  SELECT cleDate cleDateCde, Date DateCde, Jour JourCde, Mois MoisCde, Annee AnneeCde
    FROM DimDate;
")
dbExecute(dm, "
CREATE VIEW DimDateEnvoi AS
  SELECT cleDate cleDateEnvoi, Date DateEnvoi, Jour JourEnvoi, Mois MoisEnvoi, Annee AnneeEnvoi
    FROM DimDate;
")
dbExecute(dm, "
CREATE VIEW DimDateLim AS
  SELECT cleDate cleDateLim, Date DateLim, Jour JourLim, Mois MoisLim, Annee AnneeLim
    FROM DimDate;
")
dbExecute(dm, "
CREATE TABLE DimClient (
  cleClient VARCHAR2(5) NOT NULL PRIMARY KEY,
  NomClient VARCHAR2(50),
  VilleClient VARCHAR2(50),
  PaysClient VARCHAR2(50)
);
          ")
dbExecute(dm, "
CREATE TABLE DimProduit (
  cleProduit INT NOT NULL PRIMARY KEY,
  NomProduit VARCHAR2(50),
  Fournisseur VARCHAR2(50),
  PaysFournisseur VARCHAR2(50),
  Categorie VARCHAR2(50)
);
          ")
dbExecute(dm, "
CREATE TABLE DimEmploye (
  cleEmploye INT NOT NULL PRIMARY KEY,
  NomEmp VARCHAR2(50),
  PrenomEmp VARCHAR2(50),
  VilleEmp VARCHAR2(50),
  PaysEmp VARCHAR2(50)
);
          ")
dbExecute(dm, "
CREATE TABLE FaitVente (
  cleFaitVente INT NOT NULL,
  cleDate INT NOT NULL REFERENCES DimDate,
  cleClient VARCHAR2(5) NOT NULL REFERENCES DimClient,
  cleProduit INT NOT NULL REFERENCES DimProduit,
  cleEmploye INT NOT NULL REFERENCES DimEmploye,
  Messager VARCHAR2(50),
  MontantTotal NUMBER,
  PrixUnit NUMBER,
  Quantite INT,
  MontantRemise NUMBER,
  PRIMARY KEY (cleFaitVente, cleDate, cleClient, cleProduit, cleEmploye)
);")
dbExecute(dm, "
CREATE TABLE FaitCommande (
  cleFaitCde INT NOT NULL,
  cleClient VARCHAR2(5) NOT NULL REFERENCES DimClient,
  cleEmploye INT NOT NULL REFERENCES DimEmploye,
  cleDateCde INT NOT NULL REFERENCES DimDateCde,
  cleDateEnvoi INT NOT NULL REFERENCES DimDateEnvoi,
  cleDateLim INT NOT NULL REFERENCES DimDateLim,
  Messager VARCHAR2(50),
  MontantTotal NUMBER,
  Port NUMBER,
  PRIMARY KEY (cleFaitCde, cleClient, cleEmploye, cleDateCde, cleDateEnvoi, cleDateLim)
);")

dbListTables(dm)

dbDisconnect(dm)
rm(dm)

